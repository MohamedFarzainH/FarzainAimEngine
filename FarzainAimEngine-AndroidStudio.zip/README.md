# Farzain Aim Engine

Password-free Android practice application.

## What it does
- Draws a carrom-style board.
- Shows striker and coins.
- Lets you drag to choose an aiming angle.
- Calculates the first board-boundary intersection.
- Runs fully offline.
- Does not inject input, modify another app, read another app's memory, or bypass a license.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect Redmi A3 with USB debugging enabled.
4. Press Run.
5. Select the Redmi A3.

## APK
Build > Build APK(s).

Package:
com.farzain.aimeengine

Minimum Android:
7.0 (API 24)

Target:
Android 15 (API 35)
