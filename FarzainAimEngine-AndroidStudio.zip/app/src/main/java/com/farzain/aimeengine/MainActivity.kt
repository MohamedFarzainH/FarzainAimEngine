package com.farzain.aimeengine

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(AimBoardView())
    }

    inner class AimBoardView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val board = RectF()
        private var striker = PointF()
        private val coins = mutableListOf<PointF>()
        private var angle = -45.0
        private var power = 0.65f
        private var dragging = false

        init {
            paint.typeface = Typeface.create("sans", Typeface.NORMAL)
            repeat(7) { i ->
                coins += PointF(0f, 0f)
            }
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            board.set(30f, 120f, w - 30f, h - 80f)
            resetBoard()
        }

        private fun resetBoard() {
            striker.set(board.centerX(), board.bottom - 90f)
            val cx = board.centerX()
            val cy = board.centerY()
            val r = 42f
            coins[0].set(cx, cy)
            coins[1].set(cx - r, cy)
            coins[2].set(cx + r, cy)
            coins[3].set(cx - r/2, cy - r*0.86f)
            coins[4].set(cx + r/2, cy - r*0.86f)
            coins[5].set(cx - r/2, cy + r*0.86f)
            coins[6].set(cx + r/2, cy + r*0.86f)
            invalidate()
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            c.drawColor(Color.WHITE)

            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(245, 245, 245)
            c.drawRect(board, paint)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            paint.color = Color.DKGRAY
            c.drawRect(board, paint)

            drawPockets(c)
            drawCoins(c)
            drawStriker(c)
            drawAimGuide(c)
            drawHeader(c)
            drawFooter(c)
        }

        private fun drawPockets(c: Canvas) {
            paint.style = Paint.Style.FILL
            paint.color = Color.BLACK
            val r = 24f
            val pts = arrayOf(
                PointF(board.left, board.top),
                PointF(board.right, board.top),
                PointF(board.left, board.bottom),
                PointF(board.right, board.bottom)
            )
            pts.forEach { c.drawCircle(it.x, it.y, r, paint) }
        }

        private fun drawCoins(c: Canvas) {
            coins.forEachIndexed { i, p ->
                paint.style = Paint.Style.FILL
                paint.color = if (i == 0) Color.RED else Color.rgb(35,35,35)
                c.drawCircle(p.x, p.y, 15f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.color = Color.WHITE
                c.drawCircle(p.x, p.y, 15f, paint)
            }
        }

        private fun drawStriker(c: Canvas) {
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(230,230,230)
            c.drawCircle(striker.x, striker.y, 20f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.DKGRAY
            c.drawCircle(striker.x, striker.y, 20f, paint)
        }

        private fun drawAimGuide(c: Canvas) {
            val rad = Math.toRadians(angle)
            val dx = cos(rad).toFloat()
            val dy = sin(rad).toFloat()

            // Manual aiming guide only: it does not send touches or interact with another app.
            val length = min(board.width(), board.height()) * 0.75f
            val end = PointF(striker.x + dx * length, striker.y + dy * length)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            paint.color = Color.rgb(40,40,40)
            c.drawLine(striker.x, striker.y, end.x, end.y, paint)

            // Predicted first collision with board boundary.
            val hit = rayToBoard(striker, dx, dy)
            if (hit != null) {
                paint.style = Paint.Style.FILL
                paint.color = Color.rgb(120,120,120)
                c.drawCircle(hit.x, hit.y, 8f, paint)
            }
        }

        private fun rayToBoard(p: PointF, dx: Float, dy: Float): PointF? {
            val candidates = mutableListOf<Pair<Float, PointF>>()

            if (dx != 0f) {
                val t1 = (board.left - p.x) / dx
                val y1 = p.y + t1 * dy
                if (t1 > 0 && y1 in board.top..board.bottom)
                    candidates += t1 to PointF(board.left, y1)

                val t2 = (board.right - p.x) / dx
                val y2 = p.y + t2 * dy
                if (t2 > 0 && y2 in board.top..board.bottom)
                    candidates += t2 to PointF(board.right, y2)
            }
            if (dy != 0f) {
                val t3 = (board.top - p.y) / dy
                val x3 = p.x + t3 * dx
                if (t3 > 0 && x3 in board.left..board.right)
                    candidates += t3 to PointF(x3, board.top)

                val t4 = (board.bottom - p.y) / dy
                val x4 = p.x + t4 * dx
                if (t4 > 0 && x4 in board.left..board.right)
                    candidates += t4 to PointF(x4, board.bottom)
            }
            return candidates.minByOrNull { it.first }?.second
        }

        private fun drawHeader(c: Canvas) {
            paint.style = Paint.Style.FILL
            paint.color = Color.BLACK
            paint.textSize = 24f
            c.drawText("Farzain Aim Engine", 24f, 45f, paint)
            paint.textSize = 15f
            paint.color = Color.DKGRAY
            c.drawText("Practice mode • No password • Offline", 24f, 72f, paint)
        }

        private fun drawFooter(c: Canvas) {
            paint.style = Paint.Style.FILL
            paint.color = Color.DKGRAY
            paint.textSize = 16f
            c.drawText("Drag on the board to choose the angle", 24f, height - 42f, paint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true
                    updateAngle(e.x, e.y)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) updateAngle(e.x, e.y)
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    return true
                }
            }
            return true
        }

        private fun updateAngle(x: Float, y: Float) {
            angle = Math.toDegrees(
                atan2((y - striker.y).toDouble(), (x - striker.x).toDouble())
            )
            invalidate()
        }
    }
}
